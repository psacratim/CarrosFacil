# RJControls
Modern, flat, and elegant Custom Controls for Windows Forms, C#, or Visual Basic.NET. This Custon Controls library was created for educational purposes through tutorial videos. You can download the source code from the repository and modify it in your own way.

<h2>VIDEO TUTORIALS:</h2>
<a href="https://youtube.com/playlist?list=PLwG-AtjFaHdMQtyReCzPdEe6fZ57TqJUs" target="_blank">
  <img src="https://rjcodeadvance.com/wp-content/uploads/2021/06/Custom-TextBox-FULL-CSharp-WinForm-1024x576.png"/>
</a>
